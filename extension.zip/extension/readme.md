= creaer difernetes categorias.
- tengo que tener una cosa que se guarde en la base de datos que son
    las distintas categorias que tiene un men. Por que o si no seria
    terrible tener que buscar por todas los elementos guardados todas las
    categorias que hay.
    Espero no romper nada. Guardar el commit.
    - estas categorias deben estar pegadas a cada usuario.
    - ahora que ya cree la parte de categorias tengo que hacer una
    funcion en la base de datos que coja todas las categorias de un
    determinado usuario.
    - Necesito datos falsos

    - listo ya tengo el backend listo ahora a organizar el front end.
        - Necesito ver como se ponen las categorias en este momento
        seguro necesitare de llamar a un fetch para esto alguna vez
        cuando se lodee la pagina cada vez? perro yo no se como es que funciona
        esto. No creo. Solo se llama el fetch la primera vez cuando se viene el usuaruio no? no se como ver cuando es la primera vez que se viene el usuario.
        Los items se hacen en cad momento que uno pasa pero y las lista de categoria?
        Inspeccionar un poco ahora como estan para decidir que hacer